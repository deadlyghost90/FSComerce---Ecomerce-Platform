# Verdant Commerce Operations

A polished, dependency-free eCommerce admin workspace built with **HTML5, inline CSS, and vanilla JavaScript**. The visual identity is an original green-and-white system for professional commerce operations.

## Run locally

```bash
cd /home/ubuntu/medusa-admin
python3 -m http.server 4173 --bind 0.0.0.0
```

Then open `http://localhost:4173`.

## Architecture

- `index.html` contains the entire application shell and embedded design system in a `<style>` block.
- `app.js` is the only separate code file and handles hash routing, mock data, rendering, modals, search, filters, command palette, toasts, theme persistence, and navigation.
- No React, Vue, Angular, frontend framework, build step, or backend is required.

## Included modules

Overview, Products, Categories, Collections, Product Options, Tags, Orders, Draft Orders, Returns, Exchanges, Customers, Customer Groups, Inventory, Locations, Shipping, Fulfillment, Discounts, Promotions, Gift Cards, Sales Channels, Regions & Markets, Payments, Analytics, Reports, Users & Roles, API Keys, Webhooks, Integrations, General Settings, Store Configuration, Localization, Tax Settings, and Audit Log.

## Interactive features

- Responsive desktop sidebar with collapse mode and mobile drawer
- Hash-routed module screens with metrics, search, filters, tabs, status badges, tables, and row actions
- Command palette via **⌘/Ctrl + K**
- Create product/order/discount/customer/collection/resource modal flows
- Toast notifications for exports, filters, invites, profile, store switcher, and actions
- Dark mode with `localStorage` persistence
- SVG sales charts and mock commerce data
